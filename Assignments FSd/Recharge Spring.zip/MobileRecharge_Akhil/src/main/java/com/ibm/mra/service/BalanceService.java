package com.ibm.mra.service;

import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.ibm.mra.beans.Account;
import com.ibm.mra.dao.BalanceDao;

@Service("balanceService")
public class BalanceService {
	
	public boolean isValidMobileNumber(long mobile_no) {
		// TODO Auto-generated method stub
		String pattern = "[7-9]{1}[0-9]{9}";
		return (Pattern.matches(pattern, String.valueOf(mobile_no)));
 
	}
	
	@Autowired
	BalanceDao dao;
	
	@Autowired
	Account acc;
	
	public Account getAccountDetails(String mobileNo){
		return dao.getAccountDetails(mobileNo);		
	}

	public int rechargeAccount(String mobileNo, Double rechargeAmount) {
		return dao.rechargeAccount(mobileNo, rechargeAmount);
		
	}

	
}
