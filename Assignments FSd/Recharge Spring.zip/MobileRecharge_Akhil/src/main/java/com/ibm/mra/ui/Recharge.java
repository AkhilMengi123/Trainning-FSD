package com.ibm.mra.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ibm.mra.beans.Account;
import com.ibm.mra.dao.BalanceDao;
import com.ibm.mra.service.BalanceService;
import java.util.Scanner;

public class Recharge {
	public static void main(String[] args) throws IOException {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		BalanceService serv = context.getBean("balanceService", BalanceService.class);

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	//	Scanner sc = new Scanner(System.in);
		int option = 0;

		do {
			long mobile_no = 0L;
			int recharge = 0;
			System.out.println("Kindly Made a Choice");
			System.out.println("1.Balance Account Enquiry ");
			System.out.println("2. Recharge Account");
			System.out.println("3. Exit Menu");
			System.out.println("Choose an option(1/2/3)");
			try {
				option = Integer.parseInt(br.readLine());
			} catch (NumberFormatException e) {
				System.out.println("Oops! Enter correct format of mobile number!");
			}
			switch(option) {
			case 1: 
				 System.out.println("Enter your Mobile Number");
				 mobile_no = Long.parseLong(br.readLine());
				 String mobile = String.valueOf(mobile_no);
				 Account acc=serv.getAccountDetails(mobile);
				 if(acc!=null)
				 {
				 System.out.println("AccountBalanceis:"+acc);
				 }
				 else {
					 System.out.println("Error mobile number does not exists");
				 }
				 break;
			
			case 2:
				System.out.print("Enter Mobile Number: ");
				mobile_no = Long.parseLong(br.readLine());
				//long number = sc.nextLong();
				String numb = String.valueOf(mobile_no);
				System.out.print ("Enter Recharge Amount: ");
			//	int recharge = sc.nextInt();
				recharge = Integer.parseInt(br.readLine());
				String mobileNumber = String.valueOf(mobile_no);
				serv.rechargeAccount(mobileNumber, Double.valueOf(recharge));
				System.out.println("Your Account Recharge Successfully.");
				System.out.println("Available balance is Rs. " + serv.getAccountDetails(numb));
				break;
			}
		} while (option > 0 && option < 3);

		// System.out.println(serv.getAccountDetails("9682630242"));

	}
}
