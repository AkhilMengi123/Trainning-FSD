package com.ibm.mra.dao;

public interface BalanceDaoInterface {

}
