package com.ibm.axiz.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.ibm.axiz.bean.AxizBank;
import com.ibm.axiz.dao.WalletDaoClass;
import com.ibm.axiz.dao.WalletDaoInterface;

public class WalletServiceClass implements WalletServiceInterface {
	WalletDaoInterface dao = new WalletDaoClass();

	public boolean isValidMobileNumber(long mobile_no) {
		// TODO Auto-generated method stub
		String pattern = "[7-9]{1}[0-9]{9}";
		return (Pattern.matches(pattern, String.valueOf(mobile_no)));
 
	}

	public boolean isPasswordMatch(String password, String conf_pass) {

		return (password.equals(conf_pass));
	}

	public boolean createWallet(AxizBank user_wallet) {
		return dao.createWallet(user_wallet);

	}

	public boolean isWalletExist(long mobile_no, String password) {
		return dao.checkWalletDatabase(mobile_no, password);
	}

	public int showBalance(long mobile_no, String password) {

		return dao.showBalance(mobile_no, password);
	}

	public String depositMoney(long mobile_no, String password, int money) {

		return dao.depositMoney(mobile_no, password, money);
	}

	public String withdrawMoney(long mobile_no, String password, int money) {

		return dao.withdrawMoney(mobile_no, password, money);

	}

	public ArrayList<String> printAllTransaction(long mobile_no, String password) {

		 return dao.printAllTransaction(mobile_no, password);
	}

	public boolean passwordValidate(long mobile_no, String password) {

		return dao.passwordValidate(mobile_no, password);
	}

	public String transferMoney(long sender_mobile_no, String password, long receiver_mobile_no, int money) {
		return dao.transferMoney(sender_mobile_no, password, receiver_mobile_no, money);

	}
}
