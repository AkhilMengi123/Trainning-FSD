package com.ibm.axiz.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import com.ibm.axiz.bean.AxizBank;
import com.ibm.axiz.service.WalletServiceClass;
import com.ibm.axiz.service.WalletServiceInterface;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		WalletServiceInterface service = new WalletServiceClass();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int option = 0;

		do {
			long mobile_no = 0L;
			String password = "";
			System.out.println("Kindly Made a Choice");
			System.out.println("1. Create an Account");
			System.out.println("2. Already A user");

			System.out.println("3. Exit Menu");
			System.out.println("Choose an option(1/2/3)");
			try {
			option = Integer.parseInt(br.readLine());
			}catch(NumberFormatException e) {
				System.out.println("Oops! Enter correct format of mobile number!");
			}
			switch (option) {
			case 1:
				String name = "";
				

				System.out.println("Mobile number:");
				try {
				mobile_no = Long.parseLong(br.readLine());
				}catch(NumberFormatException e) {
					System.out.println("NOt Found! Enter correct format of mobile number!");
				}
				if (service.isValidMobileNumber(mobile_no)) {
					
					System.out.println("Enter password:");
					password = br.readLine();
					System.out.println("Confirm password:");
					String conf_pass = br.readLine();

					if (service.isPasswordMatch(password, conf_pass)) {
						System.out.println("Enter Name:");
						name = br.readLine();
						
					
						AxizBank user_wallet = new AxizBank(mobile_no, password, name);
					
						if(service.createWallet(user_wallet)) {
							System.out.println("Wallet created successfully!");
						}
						else {
							System.out.println("Wallet cannot be created!");
						}
						
					} else {
						System.out.println("Password does not match!");

					}

				} else {
					System.out.println("mobile number not valid!");

				}
				
				break;

			case 2:
				do {
					try {
					System.out.println("Enter your wallet associated mobile number:");
					mobile_no = Long.parseLong(br.readLine());
					}catch(NumberFormatException e) {
						System.out.println("Oops! Enter correct format of mobile number!");
					}
					System.out.println("Enter your password:");
					password = br.readLine();
					if(service.passwordValidate(mobile_no, password)) {
						System.out.println("Password Wrong! Enter the correct password!");
					}
				} while (service.passwordValidate(mobile_no, password));
				if (service.isWalletExist(mobile_no, password)) {
					int option2 = 0;
					do {
						int money = 0;
						System.out.println("User Wallet Menu-");
						System.out.println("1. Balance");
						System.out.println("2. Deposit ");
						System.out.println("3. Withdraw");
						System.out.println("4. Fund Transfer");
						System.out.println("5. Print Transactions");
						System.out.println("6. Exit");
						System.out.println("Choose an option(1/2/3/4/5/6)");
						try {
						option2 = Integer.parseInt(br.readLine());
						}catch(NumberFormatException e) {
							System.out.println("Oops! Enter correct format of mobile number!");
						};
						switch (option2) {
						case 1:

							System.out.println("Your account balance is : " + service.showBalance(mobile_no, password));
							break;

						case 2:
							System.out.println("Enter the deposit amount:");
							try {
							money = Integer.parseInt(br.readLine());
							}catch(NumberFormatException e) {
								System.out.println("Oops! Enter correct format of mobile number!");
							}
							System.out.println(service.depositMoney(mobile_no, password, money));
							break;

						case 3:
							System.out.println("Enter the withdrawal amount:");
							try {
							money = Integer.parseInt(br.readLine());
							}catch(NumberFormatException e) {
								System.out.println("Oops! Enter correct format of mobile number!");
							}
							System.out.println(service.withdrawMoney(mobile_no, password, money));
							break;
						case 4:
							try {
							System.out.println("Enter the amount you want to transfer:");
							money = Integer.parseInt(br.readLine());
							System.out.println("Enter the mobile number of receiver:");
							long receiver_mobile_no = Long.parseLong(br.readLine());
							System.out.println(service.transferMoney(mobile_no, password, receiver_mobile_no, money));
							}catch(NumberFormatException e) {
								System.out.println("Oops! Enter correct format of mobile number!");
							}
							break;

						case 5:
							System.out.println("All your transaction are listed below:");
							ArrayList<String> transaction=service.printAllTransaction(mobile_no, password);
							for(String s:transaction) {
								System.out.println(s);
							}
							break;

						}
					} while (option2 > 0 && option2 < 6);

				} else {
					System.out.println("Wallet does not exist...");
				}

				break;
			}
		} while (option > 0 && option < 3);

	}

}
